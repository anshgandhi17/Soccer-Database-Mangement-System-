

CREATE TABLE Team ( 
teamName char(50),
league char(50),  
teamOwner char(20) NOT NULL,
PRIMARY KEY (teamName,league) );

 
CREATE TABLE managerManages ( 
managerId integer PRIMARY KEY,
managerName char(50) NOT NULL, 
league char(50) NOT NULL,  
teamName char(50) NOT NULL, 
nationality char(30) NOT NULL,
age integer NOT NULL,
nationalTeam char(40) NOT NULL,
FOREIGN KEY (teamName,league) REFERENCES Team ON DELETE CASCADE 
); 


CREATE TABLE Player ( 
playerId integer PRIMARY KEY,
playerName char(50) NOT NULL, 
league char(50) NOT NULL,  
teamName char(50) NOT NULL, 
nationality char(30) NOT NULL,
jerseyNumber int NOT NULL,
goals int NOT NULL, 
salary float NOT NULL, 
FOREIGN KEY (teamName,league) REFERENCES Team ON DELETE CASCADE
); 

CREATE TABLE GoalKeeper ( 
playerId integer PRIMARY KEY,
saves integer,
FOREIGN KEY (playerId) REFERENCES Player
); 


CREATE TABLE Stadium ( 
stadiumName char(50) PRIMARY KEY, 
league char(50) NOT NULL,  
teamName char(50) NOT NULL, 
stadiumlocation char(50) NOT NULL,
sponsor char(50),
capacity integer,
FOREIGN KEY (teamName,league) REFERENCES Team ON DELETE CASCADE
); 



CREATE TABLE Referee ( 
name char(50) ,
lNumber integer PRIMARY KEY,
salary integer,
nationality char(20)
); 

CREATE TABLE Match ( 
teamName char(50),
league char(50),
teamAgainst char(50),
leagueAgainst char(50),
date_on char(12),
kickOff char(14),
outcome char(20),
lNumber integer NOT NULL,
PRIMARY KEY (teamName,league,date_on),
FOREIGN KEY (teamName,league) REFERENCES Team,
FOREIGN KEY (teamAgainst,leagueAgainst) REFERENCES Team,
FOREIGN KEY (lNumber) REFERENCES Referee
); 

CREATE TABLE Goal ( 
goalId integer PRIMARY KEY,
playerId integer NOT NULL,
teamName char(50),
league char(50),
dateOn   char(12), 
timeAt  char(50),
assist char(50),
goalType char(20),
FOREIGN KEY (playerId) REFERENCES Player ON DELETE CASCADE
);



INSERT INTO Team VALUES('FC Barcelona', 'La Liga','Josep Bartamou');
INSERT INTO Team VALUES('Real Mardrid FC', 'La Liga','Florentino Perez');
INSERT INTO Team VALUES('Liverpool', 'EPL','Fenway Sports Group');
INSERT INTO Team VALUES('Manchester City', 'EPL','City Sports Group');
INSERT INTO Team VALUES('Manchester United', 'EPL','Glazer Family');


INSERT INTO managerManages VALUES(1,'Ronald Koko', 'La Liga','FC Barcelona','Dutch',54,'Netherlands');
INSERT INTO managerManages VALUES(2,'Zid Zidane', 'La Liga','Real Mardrid FC', 'French',51,'France');
INSERT INTO managerManages VALUES(3,'Klopp', 'EPL','Liverpool','English',58,'England');
INSERT INTO managerManages VALUES(4,'Pep Guardiola', 'EPL','Manchester City', 'Spanish',62,'Spain');
INSERT INTO managerManages VALUES(5,'Sir Alex', 'EPL','Manchester United', 'German',72,'Germany');


INSERT INTO Player VALUES(1,'C Ronaldo','EPL','Manchester United','Portugese',7,12,5000000);
INSERT INTO Player VALUES(2,'L Messi','La Liga','FC Barcelona','Argentine',10,14,6000000);
INSERT INTO Player VALUES(4,'K Benzema','La Liga','Real Mardrid FC','French',9,12,4000000);
INSERT INTO Player VALUES(5,'M Salah','EPL','Liverpool','Egyptian',7,4,5400000);
INSERT INTO Player VALUES(6,'B Silva','EPL','Manchester City','Portugese',7,5,5100000);
INSERT INTO Player VALUES(10,'De Gea','EPL','Manchester United','Spanish',99,0,5000000);
INSERT INTO Player VALUES(11,'Ter Stegen','La Liga','FC Barcelona','German',98,0,6000000);
INSERT INTO Player VALUES(12,'Courtois','La Liga','Real Mardrid FC','Belgian',97,0,4000000);
INSERT INTO Player VALUES(13,'Becker','EPL','Liverpool','English',96,0,5400000);
INSERT INTO Player VALUES(14,'Ederson','EPL','Manchester City','Brazilian',95,5,5100000);

INSERT INTO GoalKeeper VALUES(10,6);
INSERT INTO GoalKeeper VALUES(11,9);
INSERT INTO GoalKeeper VALUES(12,10);
INSERT INTO GoalKeeper VALUES(13,11);
INSERT INTO GoalKeeper VALUES(14,15);


INSERT INTO Stadium VALUES('Camp Nou', 'La Liga','FC Barcelona', 'Barcelona','Rakuten',50000);
INSERT INTO Stadium VALUES('Santiago Barabeauu', 'La Liga','Real Mardrid FC', 'Madrid','Emirates',40000);
INSERT INTO Stadium VALUES('Anfield', 'EPL','Liverpool', 'Liverpool City','Standard Charter',33000);
INSERT INTO Stadium VALUES('Etihad Stadium', 'EPL','Manchester City', 'Manchester East','Etihad',47000);
INSERT INTO Stadium VALUES('Old Trattford', 'EPL','Manchester United', 'Manchester West','TeamViewer',22000);


INSERT INTO Referee VALUES('Rajesh Koothrapali',5,120000,'German');
INSERT INTO Referee VALUES('David De Roya',22,13000,'Spanish');
INSERT INTO Referee VALUES('Ansh Gandhi',17,10000,'Dutch');
INSERT INTO Referee VALUES('Sean Park',1,15000,'Canadian');
INSERT INTO Referee VALUES('Sahaj Chhabra',8,110000,'Indian');



INSERT INTO Match VALUES('FC Barcelona','La Liga','Real Mardrid FC','La Liga','2021-27-11','12:15:00','Win-Lose',5);
INSERT INTO Match VALUES('Real Mardrid FC','La Liga','FC Barcelona','La Liga','2021-17-10','15:10:00','Win-Lose',22);
INSERT INTO Match VALUES('Liverpool','EPL','Real Mardrid FC','La Liga','2020-29-11','12:15:00','Lose-Win',1);
INSERT INTO Match VALUES('Real Mardrid FC','La Liga','Manchester United','EPL','2019-10-08','15:10:00','Draw',8);
INSERT INTO Match VALUES('FC Barcelona','La Liga','Manchester United','EPL','2019-10-08','15:10:00','Win-Lose',17);

INSERT INTO Goal VALUES(11,1,'Manchester United','EPL','2021-10-24','20:29:19.99','Bruno','Freekick');
INSERT INTO Goal VALUES(12,2,'FC Barcelona','La Liga','2021-09-24','20:29:19.99','Suarez','Normal');
INSERT INTO Goal VALUES(13,4,'Real Mardrid FC','La Liga','2021-08-24','20:29:19.99','','Penalty');
INSERT INTO Goal VALUES(14,5,'Liverpool','EPL','2021-07-24','20:29:19.99','Kloppper','Freekick');
INSERT INTO Goal VALUES(15,6,'Manchester City','EPL','2021-06-24','20:29:19.99','Ederson','Normal');